// =============================================================================
// ELECTRON MAIN PROCESS: main.js
// Handles desktop lifecycle, window creation, and Node.js environment setup
// =============================================================================

const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');

let mainWindow = null;

function createWindow() {
  // Create the native browser window
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 960,
    minHeight: 650,
    title: 'Athenaeum - Library Management System',
    backgroundColor: '#0f172a', // Deep slate neutral canvas
    webPreferences: {
      // Enables full Node.js API access (such as 'fs', 'path') directly inside renderer.js
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true
    },
    show: false // Wait until ready-to-show to prevent visual flash
  });

  // Load the primary user interface file
  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  // Smoothly show window once DOM and styles are parsed
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Optional: Build clean desktop application menu
  const menuTemplate = [
    {
      label: 'File',
      submenu: [
        { label: 'Reload App', accelerator: 'CmdOrCtrl+R', click: () => mainWindow.reload() },
        { type: 'separator' },
        { label: 'Quit', accelerator: 'CmdOrCtrl+Q', click: () => app.quit() }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'selectAll' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'togglefullscreen' },
        { label: 'Toggle Developer Tools', accelerator: 'F12', click: () => mainWindow.webContents.toggleDevTools() }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(menuTemplate);
  Menu.setApplicationMenu(menu);

  // Clean up memory reference when window is closed
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Initialize Electron application
app.whenReady().then(() => {
  createWindow();

  // On macOS re-create window when dock icon is clicked and no windows are open
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

// Terminate application when all windows are closed (standard behavior on Windows & Linux)
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});