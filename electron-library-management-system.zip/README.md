# Athenaeum - Desktop Library Management System

A complete, offline-capable desktop application built with **Electron.js**, **Node.js `fs`**, **HTML5**, **CSS3**, and **JavaScript**.

---

## 📁 Project File Structure

```
library-management-system/
├── package.json       # Electron scripts & dependencies
├── main.js            # Electron Main Process (Window & app lifecycle)
├── index.html         # User Interface layout & modals
├── style.css          # Responsive desktop stylesheet
├── renderer.js        # Renderer process & database.json read/write logic
├── database.json      # Offline local JSON storage
└── README.md          # Setup and build instructions
```

---

## 🚀 Quick Start Guide

### Step 1: Initialize Project Directory
Open your terminal (PowerShell, Command Prompt, or Bash):
```bash
mkdir library-app
cd library-app
```

### Step 2: Initialize npm & Install Electron
```bash
npm init -y
npm install --save-dev electron
```

### Step 3: Create the Project Files
Create the files (`main.js`, `index.html`, `style.css`, `renderer.js`, and `database.json`) in your folder and paste the corresponding code from this repository.

### Step 4: Verify package.json
Make sure your `package.json` has `"main": "main.js"` and the start script:
```json
"scripts": {
  "start": "electron ."
}
```

### Step 5: Launch the Application
```bash
npm start
```

---

## 🛠️ Key Features
- **Dashboard Metrics**: Real-time counter of Total Books, Issued Books, and Available Books.
- **Add New Book**: Register book with Title, Author, Category, and unique ISBN validation.
- **Real-Time Search & Filtering**: Instant search across titles, authors, and ISBNs + Category dropdown and status segmented tabs.
- **Issue & Return Workflow**:
  - Issue books with Member Name, Library Card ID, and Due Date calculation.
  - Return books back to available shelves with 1-click.
  - Delete books with confirmation prompt.
- **100% Offline Local Storage**: Synchronous and safe `fs.readFileSync` / `fs.writeFileSync` directly to `database.json`.

---

## 📦 Packaging into Standalone Executables (.exe / .dmg / AppImage)
To create a standalone installer or executable:
```bash
npm install --save-dev electron-packager
npx electron-packager . LibraryManager --platform=win32 --arch=x64 --out=dist
```
