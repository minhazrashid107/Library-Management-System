// =============================================================================
// ELECTRON RENDERER PROCESS: renderer.js
// Handles database.json reading/writing using Node.js 'fs' module & UI interactions
// =============================================================================

// In Electron with nodeIntegration: true, we have full access to Node.js modules!
const fs = require('fs');
const path = require('path');

// Resolve the absolute path to database.json in the application root directory
const DB_PATH = path.join(__dirname, 'database.json');

// Global state in renderer memory
let libraryState = {
  books: [],
  categories: [],
  lastUpdated: new Date().toISOString()
};

let currentFilter = {
  searchQuery: '',
  category: 'All',
  status: 'All'
};

// =============================================================================
// 1. DATABASE FILE OPERATIONS (fs MODULE)
// =============================================================================

/**
 * Initializes database.json if it doesn't exist yet, or reads existing books
 */
function initDatabase() {
  try {
    if (!fs.existsSync(DB_PATH)) {
      // Create initial seed data if file does not exist
      const defaultData = {
        books: [
          {
            id: 'b-101',
            title: 'Clean Code: A Handbook of Agile Software Craftsmanship',
            author: 'Robert C. Martin',
            category: 'Computer Science',
            isbn: '978-0132350884',
            status: 'Available',
            addedAt: '2026-01-15'
          },
          {
            id: 'b-102',
            title: 'Design Patterns: Elements of Reusable Object-Oriented Software',
            author: 'Erich Gamma, Richard Helm, Ralph Johnson, John Vlissides',
            category: 'Computer Science',
            isbn: '978-0201633610',
            status: 'Issued',
            issuedTo: {
              memberName: 'Sarah Jenkins',
              memberId: 'LIB-4092',
              issueDate: '2026-11-01',
              dueDate: '2026-11-15'
            },
            addedAt: '2026-01-18'
          },
          {
            id: 'b-103',
            title: 'The Pragmatic Programmer: Your Journey To Mastery',
            author: 'David Thomas, Andrew Hunt',
            category: 'Computer Science',
            isbn: '978-0135957059',
            status: 'Available',
            addedAt: '2026-02-04'
          },
          {
            id: 'b-104',
            title: 'To Kill a Mockingbird',
            author: 'Harper Lee',
            category: 'Fiction & Literature',
            isbn: '978-0060935467',
            status: 'Available',
            addedAt: '2026-02-12'
          }
        ],
        categories: [
          'Computer Science',
          'Fiction & Literature',
          'Science & Physics',
          'History & Biography',
          'Philosophy & Ethics',
          'Economics & Business'
        ],
        lastUpdated: new Date().toISOString()
      };

      // Write default seed file cleanly with 2 spaces formatting
      fs.writeFileSync(DB_PATH, JSON.stringify(defaultData, null, 2), 'utf-8');
      libraryState = defaultData;
      showToast('Created initial database.json file', 'info');
    } else {
      // Read existing data from database.json
      const rawData = fs.readFileSync(DB_PATH, 'utf-8');
      libraryState = JSON.parse(rawData);
    }

    updateDbStatusBadge(true);
  } catch (error) {
    console.error('Failed to read or initialize database.json:', error);
    updateDbStatusBadge(false);
    showToast('Error reading database.json: ' + error.message, 'danger');
  }
}

/**
 * Persists current library state to database.json on local disk
 */
function saveDatabase() {
  try {
    libraryState.lastUpdated = new Date().toISOString();
    fs.writeFileSync(DB_PATH, JSON.stringify(libraryState, null, 2), 'utf-8');
    updateDbStatusBadge(true);
    return true;
  } catch (error) {
    console.error('Failed to write to database.json:', error);
    updateDbStatusBadge(false);
    showToast('Failed to write to database.json: ' + error.message, 'danger');
    return false;
  }
}

function updateDbStatusBadge(isConnected) {
  const badge = document.getElementById('dbStatus');
  if (!badge) return;
  if (isConnected) {
    badge.textContent = 'database.json: Synced';
    badge.style.color = '#4ade80';
    badge.style.borderColor = 'rgba(34, 197, 94, 0.3)';
  } else {
    badge.textContent = 'database.json: Error';
    badge.style.color = '#ef4444';
    badge.style.borderColor = 'rgba(239, 68, 68, 0.3)';
  }
}

// =============================================================================
// 2. DASHBOARD KPI METRICS
// =============================================================================

function updateDashboardKPIs() {
  const total = libraryState.books.length;
  const issued = libraryState.books.filter(b => b.status === 'Issued').length;
  const available = total - issued;

  document.getElementById('statTotalBooks').textContent = total;
  document.getElementById('statIssuedBooks').textContent = issued;
  document.getElementById('statAvailableBooks').textContent = available;
}

// =============================================================================
// 3. TABLE RENDERING & FILTERING
// =============================================================================

function getFilteredBooks() {
  const query = currentFilter.searchQuery.trim().toLowerCase();
  const category = currentFilter.category;
  const status = currentFilter.status;

  return libraryState.books.filter(book => {
    // Search query match across Title, Author, or ISBN
    const matchSearch =
      query === '' ||
      book.title.toLowerCase().includes(query) ||
      book.author.toLowerCase().includes(query) ||
      book.isbn.toLowerCase().includes(query);

    // Category match
    const matchCategory =
      category === 'All' || book.category === category;

    // Status match
    const matchStatus =
      status === 'All' || book.status === status;

    return matchSearch && matchCategory && matchStatus;
  });
}

function renderBookTable() {
  const tbody = document.getElementById('booksTableBody');
  const emptyState = document.getElementById('emptyState');
  const resultsCount = document.getElementById('resultsCount');

  const filteredBooks = getFilteredBooks();
  resultsCount.textContent = `Showing ${filteredBooks.length} of ${libraryState.books.length} books`;

  tbody.innerHTML = '';

  if (filteredBooks.length === 0) {
    emptyState.style.display = 'block';
    return;
  }

  emptyState.style.display = 'none';

  filteredBooks.forEach(book => {
    const tr = document.createElement('tr');

    const isAvailable = book.status === 'Available';
    const statusPillClass = isAvailable ? 'available' : 'issued';

    let borrowerSnippet = '';
    if (!isAvailable && book.issuedTo) {
      borrowerSnippet = `
        <span class="borrower-meta">
          Issued to: <strong>${escapeHtml(book.issuedTo.memberName)}</strong> (Due: ${book.issuedTo.dueDate})
        </span>
      `;
    }

    tr.innerHTML = `
      <td>
        <div class="book-title-cell">
          <div class="title">${escapeHtml(book.title)}</div>
          <div class="author">by ${escapeHtml(book.author)}</div>
        </div>
      </td>
      <td>
        <span class="category-text">${escapeHtml(book.category)}</span>
      </td>
      <td>
        <code class="isbn-code">${escapeHtml(book.isbn)}</code>
      </td>
      <td>
        <span class="status-pill ${statusPillClass}">
          ${book.status}
        </span>
        ${borrowerSnippet}
      </td>
      <td>
        <div class="table-actions">
          ${
            isAvailable
              ? `<button class="btn btn-sm btn-warning" onclick="openIssueModal('${book.id}')">Issue Book</button>`
              : `<button class="btn btn-sm btn-success" onclick="returnBook('${book.id}')">Return Book</button>`
          }
          <button class="btn btn-sm btn-danger" onclick="deleteBook('${book.id}')" title="Delete book">Delete</button>
        </div>
      </td>
    `;

    tbody.appendChild(tr);
  });
}

// =============================================================================
// 4. BOOK ACTIONS (ADD, ISSUE, RETURN, DELETE)
// =============================================================================

function addNewBook(title, author, category, isbn) {
  // Check for duplicate ISBN
  const exists = libraryState.books.some(b => b.isbn.trim().toLowerCase() === isbn.trim().toLowerCase());
  if (exists) {
    showToast('A book with this ISBN already exists!', 'danger');
    return false;
  }

  const newBook = {
    id: 'b-' + Date.now(),
    title: title.trim(),
    author: author.trim(),
    category: category,
    isbn: isbn.trim(),
    status: 'Available',
    addedAt: new Date().toISOString().split('T')[0]
  };

  libraryState.books.unshift(newBook);
  if (saveDatabase()) {
    updateDashboardKPIs();
    renderBookTable();
    showToast(`"${newBook.title}" added successfully!`, 'success');
    return true;
  }
  return false;
}

window.openIssueModal = function(bookId) {
  const book = libraryState.books.find(b => b.id === bookId);
  if (!book) return;

  document.getElementById('issueBookId').value = book.id;
  document.getElementById('issueBookSummary').innerHTML = `
    <strong>${escapeHtml(book.title)}</strong><br>
    <span class="text-secondary">ISBN: ${escapeHtml(book.isbn)} · Author: ${escapeHtml(book.author)}</span>
  `;

  // Default return due date to 14 days from today
  const defaultDueDate = new Date();
  defaultDueDate.setDate(defaultDueDate.getDate() + 14);
  document.getElementById('dueDate').value = defaultDueDate.toISOString().split('T')[0];

  document.getElementById('memberName').value = '';
  document.getElementById('memberId').value = '';
  document.getElementById('issueModal').style.display = 'flex';
};

function confirmIssueBook(bookId, memberName, memberId, dueDate) {
  const book = libraryState.books.find(b => b.id === bookId);
  if (!book) return;

  book.status = 'Issued';
  book.issuedTo = {
    memberName: memberName.trim(),
    memberId: memberId.trim(),
    issueDate: new Date().toISOString().split('T')[0],
    dueDate: dueDate
  };

  if (saveDatabase()) {
    updateDashboardKPIs();
    renderBookTable();
    showToast(`Book issued to ${memberName}`, 'success');
  }
}

window.returnBook = function(bookId) {
  const book = libraryState.books.find(b => b.id === bookId);
  if (!book) return;

  if (confirm(`Confirm returning "${book.title}" to available shelf inventory?`)) {
    book.status = 'Available';
    delete book.issuedTo;

    if (saveDatabase()) {
      updateDashboardKPIs();
      renderBookTable();
      showToast(`Book "${book.title}" marked as Returned!`, 'success');
    }
  }
};

window.deleteBook = function(bookId) {
  const book = libraryState.books.find(b => b.id === bookId);
  if (!book) return;

  if (confirm(`Are you sure you want to delete "${book.title}" permanently from database.json?`)) {
    libraryState.books = libraryState.books.filter(b => b.id !== bookId);

    if (saveDatabase()) {
      updateDashboardKPIs();
      renderBookTable();
      showToast(`Book deleted from database`, 'info');
    }
  }
};

// =============================================================================
// 5. EVENT LISTENERS & MODAL CONTROLS
// =============================================================================

document.addEventListener('DOMContentLoaded', () => {
  // Load data from database.json
  initDatabase();
  updateDashboardKPIs();
  renderBookTable();

  // Search input with real-time debounce/immediate response
  const searchInput = document.getElementById('searchInput');
  const clearSearchBtn = document.getElementById('clearSearchBtn');

  searchInput.addEventListener('input', (e) => {
    currentFilter.searchQuery = e.target.value;
    renderBookTable();
  });

  clearSearchBtn.addEventListener('click', () => {
    searchInput.value = '';
    currentFilter.searchQuery = '';
    renderBookTable();
  });

  // Category filter dropdown
  const categoryFilter = document.getElementById('categoryFilter');
  categoryFilter.addEventListener('change', (e) => {
    currentFilter.category = e.target.value;
    renderBookTable();
  });

  // Status segmented tabs
  const statusTabs = document.querySelectorAll('.status-tab');
  statusTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      statusTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentFilter.status = tab.getAttribute('data-status');
      renderBookTable();
    });
  });

  // Add Book Modal Open/Close
  const addModal = document.getElementById('addBookModal');
  const openAddBtn = document.getElementById('openAddModalBtn');
  const emptyAddBtn = document.getElementById('emptyAddBtn');
  const closeAddBtn = document.getElementById('closeAddModalBtn');
  const cancelAddBtn = document.getElementById('cancelAddBtn');
  const addBookForm = document.getElementById('addBookForm');

  function openAddModal() {
    addBookForm.reset();
    addModal.style.display = 'flex';
    document.getElementById('bookTitle').focus();
  }

  function closeAddModal() {
    addModal.style.display = 'none';
  }

  openAddBtn.addEventListener('click', openAddModal);
  if (emptyAddBtn) emptyAddBtn.addEventListener('click', openAddModal);
  closeAddBtn.addEventListener('click', closeAddModal);
  cancelAddBtn.addEventListener('click', closeAddModal);

  addBookForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const title = document.getElementById('bookTitle').value;
    const author = document.getElementById('bookAuthor').value;
    const category = document.getElementById('bookCategory').value;
    const isbn = document.getElementById('bookIsbn').value;

    if (addNewBook(title, author, category, isbn)) {
      closeAddModal();
    }
  });

  // Issue Book Modal Open/Close
  const issueModal = document.getElementById('issueModal');
  const closeIssueBtn = document.getElementById('closeIssueModalBtn');
  const cancelIssueBtn = document.getElementById('cancelIssueBtn');
  const issueBookForm = document.getElementById('issueBookForm');

  function closeIssueModal() {
    issueModal.style.display = 'none';
  }

  closeIssueBtn.addEventListener('click', closeIssueModal);
  cancelIssueBtn.addEventListener('click', closeIssueModal);

  issueBookForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const bookId = document.getElementById('issueBookId').value;
    const memberName = document.getElementById('memberName').value;
    const memberId = document.getElementById('memberId').value;
    const dueDate = document.getElementById('dueDate').value;

    confirmIssueBook(bookId, memberName, memberId, dueDate);
    closeIssueModal();
  });

  // Quick Seed Sample Books
  const quickSeedBtn = document.getElementById('quickSeedBtn');
  quickSeedBtn.addEventListener('click', () => {
    if (confirm('Re-seed database.json with curated sample books?')) {
      initDatabase();
      updateDashboardKPIs();
      renderBookTable();
      showToast('Sample books loaded into database.json', 'success');
    }
  });
});

// =============================================================================
// 6. UTILITY FUNCTIONS
// =============================================================================

function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 200);
  }, 3000);
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}